'use strict';

Object.assign(icons, {
  signal:'<path d="M4 18v2M9 13v7M14 8v12M19 3v17"/>',
  battery:'<rect x="2" y="6" width="18" height="12" rx="2"/><path d="M23 10v4M5 9v6M8 9v6M11 9v6M14 9v6"/>',
  location:'<path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/>',
  target:'<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
  select:'<path d="m5 3 13 9-7 2-3 7Z"/>',
  box:'<path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5M7 7h10v10H7Z"/>',
  undo:'<path d="m4 6 5 4-5 4V6Zm5 4h5a6 6 0 0 1 0 12"/>',
  back:'<path d="m14 5-7 7 7 7"/>',
});

const navItems = [['overview','工作台','overview'],['projects','项目','folder'],['console','巡检','camera'],['gallery','影像','image'],['reports','报告','report'],['settings','设备','settings']];
const projects = [
  {id:'PS-20261008-01',name:'海上风场 · 08 号机组',location:'江苏 · 如东海上风场',fan:'GW 6.0-154',blade:'B02',length:75,status:'running',date:'2026.10.08',images:24,marks:3},
  {id:'PS-20261007-03',name:'海上风场 · 12 号机组',location:'江苏 · 如东海上风场',fan:'GW 6.0-154',blade:'B01',length:75,status:'review',date:'2026.10.07',images:36,marks:4},
  {id:'PS-20261007-02',name:'山地风场 · 03 号机组',location:'河北 · 张北风场',fan:'MY 3.0-145',blade:'B03',length:70,status:'done',date:'2026.10.07',images:28,marks:0},
  {id:'PS-20261006-01',name:'山地风场 · 06 号机组',location:'河北 · 张北风场',fan:'MY 3.0-145',blade:'B02',length:70,status:'done',date:'2026.10.06',images:32,marks:2},
  {id:'PS-20261005-02',name:'沿海风场 · 21 号机组',location:'山东 · 东营风场',fan:'EN 5.0-156',blade:'B01',length:76,status:'done',date:'2026.10.05',images:41,marks:1},
  {id:'PS-20261004-01',name:'沿海风场 · 16 号机组',location:'山东 · 东营风场',fan:'EN 5.0-156',blade:'B03',length:76,status:'done',date:'2026.10.04',images:33,marks:2},
];
const defects = [
  {name:'内腔表面裂纹',type:'裂纹',distance:18.42,saved:false},
  {name:'粘接区域异常',type:'粘接异常',distance:23.16,saved:false},
  {name:'表面磨损记录',type:'磨损',distance:31.08,saved:true},
];
const state = {page:'overview',activeProject:projects[0],filter:'all',search:'',camera:'front',channel:'ptz',zoom:1,panX:0,panY:0,mileage:18.42,speed:.15,motion:0,steering:0,recording:false,recordStarted:0,recordElapsed:0,reportActive:false,captures:0,mode:'pointcloud',annotationTool:'select',selectedDefect:0,marks:[],settings:{}};
try { state.settings = JSON.parse(localStorage.getItem('pipesight.tablet.settings') || '{}'); } catch { state.settings={}; }
const statusLabels = {running:'巡检中',review:'待复核',done:'已完成'};
const tag = status => `<span class="tag bx--tag bx--tag--${{running:'blue',review:'warm-gray',done:'green'}[status]} ${status}">${statusLabels[status]}</span>`;
const button = (label,action,style='primary',glyph='arrow',extra='') => `<button type="button" class="button bx--btn bx--btn--${{primary:'primary',secondary:'tertiary',ghost:'ghost',light:'tertiary',text:'ghost',danger:'danger'}[style]||'primary'} ${style}" data-action="${action}" ${extra}><span>${label}</span>${glyph?icon(glyph).replace('class="icon"','class="icon bx--btn__icon"'):''}</button>`;
const emptyState = (title,description) => `<div class="empty-state">${icon('image')}<h3>${title}</h3><p>${description}</p></div>`;
const pageHead = (title,sub,action='') => `<div class="page-head"><div><h1>${title}</h1><p class="page-subtitle">${sub}</p></div>${action}</div>`;

function turbineArt() {
  return `<svg class="hero-art" viewBox="0 0 430 300" preserveAspectRatio="xMidYMid slice" aria-label="风机叶片结构示意" role="img"><defs><linearGradient id="tablet-tower"><stop stop-color="#a8a8a8"/><stop offset=".5" stop-color="#e0e0e0"/><stop offset="1" stop-color="#8d8d8d"/></linearGradient><linearGradient id="tablet-blade" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e0e0e0"/><stop offset=".6" stop-color="#a8a8a8"/><stop offset="1" stop-color="#8d8d8d"/></linearGradient><radialGradient id="tablet-glow"><stop stop-color="#d0e2ff" stop-opacity=".8"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient></defs><circle cx="238" cy="165" r="202" fill="url(#tablet-glow)"/><g stroke="#a8a8a8" fill="none"><circle cx="238" cy="140" r="106" opacity=".2"/><circle cx="238" cy="140" r="130" opacity=".2" stroke-dasharray="2 7"/><path d="M238 0v17m0 245v17M97 140h21m240 0h21" opacity=".5"/><path d="m60 299 178-63 170 63m-265 0 95-63 89 63M0 266h430M70 251h330" opacity=".12"/></g><path d="m224 315 10-172h10l13 172Z" fill="url(#tablet-tower)"/><path d="m235 139-12-17 5-95 9-64 8 82-2 70-5 24Z" fill="url(#tablet-blade)"/><path d="m245 137 24 4 62 48 46 54-71-35-56-48-12-15Z" fill="url(#tablet-blade)"/><path d="m232 148-15 21-83 28-64 8 71-29 65-33 28-1Z" fill="url(#tablet-blade)"/><circle cx="237" cy="141" r="12" fill="url(#tablet-tower)"/><circle cx="237" cy="141" r="5" fill="#d6e3f4"/><path d="m309 189 25-17h69" stroke="#0f62fe" fill="none"/><circle cx="309" cy="189" r="4" fill="#0f62fe"/><circle cx="309" cy="189" r="8" fill="none" stroke="#78a9ff" stroke-opacity=".6"/><text x="344" y="162" font-family="Consolas,monospace" font-size="10" fill="#525252">BLADE 02</text></svg>`;
}
