param(
    [ValidateSet('overview', 'projects', 'console', 'inspect3d', 'gallery', 'reports', 'settings')]
    [string]$Page = 'overview'
)
$ErrorActionPreference = 'Stop'
$prototypePath = Join-Path -Path $PSScriptRoot -ChildPath 'index.html'
if (-not (Test-Path -LiteralPath $prototypePath -PathType Leaf)) {
    throw "Prototype not found: $prototypePath"
}
$prototypeUri = [System.Uri]::new((Resolve-Path -LiteralPath $prototypePath).Path).AbsoluteUri
$previewUri = "$prototypeUri#$Page"
$chromePath = 'C:/Program Files/Google/Chrome/Application/chrome.exe'
if (Test-Path -LiteralPath $chromePath -PathType Leaf) {
    Start-Process -FilePath $chromePath -ArgumentList @('--new-window', '--window-size=1280,900', $previewUri)
} else {
    Start-Process -FilePath $previewUri
}
